package com.valten;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DPApplication {

    public static void main(String[] args) {
        SpringApplication.run(DPApplication.class, args);
    }

}
